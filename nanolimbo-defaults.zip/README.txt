English Tutorial:

Well.. you are using BungeeCord.
LimboSecure requires NanoLimboPlugin to be installed.
I am not going to share the jar here because I want to support the original creator.
Go ahead and download it from: https://www.spigotmc.org/resources/nanolimboplugin.105297/
Once you download it, drag/drop it to your plugins folder (bungee).
And copy/paste the folder we gave you to the same folder. (only the NanoLimboPlugin directory)
You may need to edit "infoForwarding" section in the NanoLimboPlugin/limbo/settings.yml
Make sure it is what you use for your server.
And start the server.
And you are all set.

Turkish Tutorial:

Görünen o ki BungeeCord kullanıyorsun.
LimboSecure, NanoLimboPlugin gerektirir.
Jar'ı burada vermeyeceğim çünkü geliştiriciyi desteklemek istiyorum.
NanoLimboPlugin'i https://www.spigotmc.org/resources/nanolimboplugin.105297/ üzerinden indirebilirsin.
İndirdiğin Jar'ı plugins klasörüne sürükle ve bırak. (bungee)
Bu zip'in içindeki klasörü de aynı şekilde plugins klasörüne bırak.
"infoForwarding" kısmını düzenlemen gerekebilir. (NanoLimboPlugin/limbo/settings.yml)
Sunucundaki koruma düzeyine bağlı olarak doğru şekilde ayarladığına emin ol.
Ayarladıktan sonra ise sunucuyu başlat.
Ve hazırsın.